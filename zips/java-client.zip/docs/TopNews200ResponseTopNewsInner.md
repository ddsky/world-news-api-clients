

# TopNews200ResponseTopNewsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**news** | [**List&lt;TopNews200ResponseTopNewsInnerNewsInner&gt;**](TopNews200ResponseTopNewsInnerNewsInner.md) |  |  [optional] |



