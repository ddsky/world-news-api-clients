

# InlineResponse200


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Integer** |  | 
**number** | **Integer** |  | 
**available** | **Integer** |  | 
**news** | [**List&lt;InlineResponse200News&gt;**](InlineResponse200News.md) |  | 



