

# SearchNews200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**offset** | **Integer** |  |  |
|**number** | **Integer** |  |  |
|**available** | **Integer** |  |  |
|**news** | [**List&lt;SearchNews200ResponseNewsInner&gt;**](SearchNews200ResponseNewsInner.md) |  |  |



