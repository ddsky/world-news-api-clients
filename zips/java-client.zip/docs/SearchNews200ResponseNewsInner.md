

# SearchNews200ResponseNewsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**summary** | **String** |  |  [optional] |
|**image** | **String** |  |  [optional] |
|**sentiment** | **BigDecimal** |  |  [optional] |
|**author** | **String** |  |  [optional] |
|**language** | **String** |  |  [optional] |
|**video** | **String** |  |  [optional] |
|**title** | **String** |  |  [optional] |
|**url** | **String** |  |  [optional] |
|**sourceCountry** | **String** |  |  [optional] |
|**id** | **Integer** |  |  [optional] |
|**text** | **String** |  |  [optional] |
|**publishDate** | **String** |  |  [optional] |
|**authors** | **List&lt;String&gt;** |  |  [optional] |



