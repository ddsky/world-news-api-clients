

# GeoCoordinates200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**latitude** | **BigDecimal** |  |  |
|**longitude** | **BigDecimal** |  |  |
|**city** | **String** |  |  [optional] |



