

# InlineResponse200News


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**title** | **String** |  |  [optional]
**text** | **String** |  |  [optional]
**summary** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**image** | **String** |  |  [optional]
**author** | **String** |  |  [optional]
**language** | **String** |  |  [optional]
**sourceCountry** | **String** |  |  [optional]
**sentiment** | **BigDecimal** |  |  [optional]



