

# GetGeoCoordinates200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**latitude** | **BigDecimal** |  |  [optional] |
|**longitude** | **BigDecimal** |  |  [optional] |
|**city** | **String** |  |  [optional] |



