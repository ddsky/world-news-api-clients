

# SearchNewsResponse


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**offset** | **Integer** |  |  |
|**number** | **Integer** |  |  |
|**available** | **Integer** |  |  |
|**news** | [**List&lt;NewsArticle&gt;**](NewsArticle.md) |  |  |



