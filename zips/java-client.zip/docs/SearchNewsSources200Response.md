

# SearchNewsSources200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**available** | **Integer** |  |  [optional] |
|**sources** | [**List&lt;SearchNewsSources200ResponseSourcesInner&gt;**](SearchNewsSources200ResponseSourcesInner.md) |  |  [optional] |



