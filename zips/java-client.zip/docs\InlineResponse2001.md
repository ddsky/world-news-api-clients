

# InlineResponse2001


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  |  [optional]
**text** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**image** | **String** |  |  [optional]
**author** | **String** |  |  [optional]
**language** | **String** |  |  [optional]
**sourceCountry** | **String** |  |  [optional]
**sentiment** | **BigDecimal** |  |  [optional]



