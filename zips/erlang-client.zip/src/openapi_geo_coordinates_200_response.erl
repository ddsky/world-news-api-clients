-module(openapi_geo_coordinates_200_response).

-export([encode/1]).

-export_type([openapi_geo_coordinates_200_response/0]).

-type openapi_geo_coordinates_200_response() ::
    #{ 'latitude' := integer(),
       'longitude' := integer(),
       'city' => binary()
     }.

encode(#{ 'latitude' := Latitude,
          'longitude' := Longitude,
          'city' := City
        }) ->
    #{ 'latitude' => Latitude,
       'longitude' => Longitude,
       'city' => City
     }.
