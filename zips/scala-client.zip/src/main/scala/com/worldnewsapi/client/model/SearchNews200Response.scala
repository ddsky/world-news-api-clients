package com.worldnewsapi.client.model

import io.circe._
import io.finch.circe._
import io.circe.generic.semiauto._
import io.circe.java8.time._
import org.openapitools._
import com.worldnewsapi.client.model.SearchNews200ResponseNewsInner
import scala.collection.immutable.Seq

/**
 * 
 * @param offset 
 * @param number 
 * @param available 
 * @param news 
 */
case class SearchNews200Response(offset: Int,
                number: Int,
                available: Int,
                news: Seq[SearchNews200ResponseNewsInner]
                )

object SearchNews200Response {
    /**
     * Creates the codec for converting SearchNews200Response from and to JSON.
     */
    implicit val decoder: Decoder[SearchNews200Response] = deriveDecoder
    implicit val encoder: ObjectEncoder[SearchNews200Response] = deriveEncoder
}
