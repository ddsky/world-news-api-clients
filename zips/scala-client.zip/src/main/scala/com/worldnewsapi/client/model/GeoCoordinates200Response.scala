package com.worldnewsapi.client.model

import io.circe._
import io.finch.circe._
import io.circe.generic.semiauto._
import io.circe.java8.time._
import org.openapitools._
import com.worldnewsapi.client.model.BigDecimal

/**
 * 
 * @param latitude 
 * @param longitude 
 * @param city 
 */
case class GeoCoordinates200Response(latitude: BigDecimal,
                longitude: BigDecimal,
                city: Option[String]
                )

object GeoCoordinates200Response {
    /**
     * Creates the codec for converting GeoCoordinates200Response from and to JSON.
     */
    implicit val decoder: Decoder[GeoCoordinates200Response] = deriveDecoder
    implicit val encoder: ObjectEncoder[GeoCoordinates200Response] = deriveEncoder
}
