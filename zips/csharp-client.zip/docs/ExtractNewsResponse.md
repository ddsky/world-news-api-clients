# worldnewsapi.Model.ExtractNewsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** |  | [optional] 
**Text** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 
**Image** | **string** |  | [optional] 
**Author** | **string** |  | [optional] 
**Language** | **string** |  | [optional] 
**SourceCountry** | **string** |  | [optional] 
**Sentiment** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

