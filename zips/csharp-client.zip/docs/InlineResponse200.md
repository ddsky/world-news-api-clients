# Org.OpenAPITools.Model.InlineResponse200

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offset** | **int?** |  | 
**Number** | **int?** |  | 
**Available** | **int?** |  | 
**News** | [**List<InlineResponse200News>**](InlineResponse200News.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

