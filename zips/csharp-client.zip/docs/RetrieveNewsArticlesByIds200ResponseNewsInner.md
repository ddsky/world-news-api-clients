# worldnewsapi.Model.RetrieveNewsArticlesByIds200ResponseNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Summary** | **string** |  | [optional] 
**Image** | **string** |  | [optional] 
**Sentiment** | **decimal** |  | [optional] 
**Catgory** | **string** |  | [optional] 
**Language** | **string** |  | [optional] 
**Title** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 
**SourceCountry** | **string** |  | [optional] 
**Id** | **int** |  | [optional] 
**Text** | **string** |  | [optional] 
**PublishDate** | **string** |  | [optional] 
**Authors** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

