# worldnewsapi.Model.NewspaperFrontPages200ResponseFrontPage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Date** | **string** |  | [optional] 
**Country** | **string** |  | [optional] 
**Image** | **string** |  | [optional] 
**Language** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

