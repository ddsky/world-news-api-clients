# worldnewsapi.Model.TopNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TopNews** | [**List&lt;TopNews200ResponseTopNewsInner&gt;**](TopNews200ResponseTopNewsInner.md) |  | [optional] 
**Language** | **string** |  | [optional] 
**Country** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

