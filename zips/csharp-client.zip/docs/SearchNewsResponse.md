# worldnewsapi.Model.SearchNewsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offset** | **int** |  | 
**Number** | **int** |  | 
**Available** | **int** |  | 
**News** | [**List&lt;NewsArticle&gt;**](NewsArticle.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

