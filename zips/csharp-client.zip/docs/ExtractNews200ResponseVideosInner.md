# worldnewsapi.Model.ExtractNews200ResponseVideosInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Summary** | **string** |  | [optional] 
**Duration** | **int** |  | [optional] 
**Thumbnail** | **string** |  | [optional] 
**Title** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

