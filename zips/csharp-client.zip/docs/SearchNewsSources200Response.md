# worldnewsapi.Model.SearchNewsSources200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Available** | **int** |  | [optional] 
**Sources** | [**List&lt;SearchNewsSources200ResponseSourcesInner&gt;**](SearchNewsSources200ResponseSourcesInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

