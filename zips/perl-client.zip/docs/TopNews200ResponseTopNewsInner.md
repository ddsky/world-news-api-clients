# WWW::OpenAPIClient::Object::TopNews200ResponseTopNewsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::TopNews200ResponseTopNewsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**news** | [**ARRAY[TopNews200ResponseTopNewsInnerNewsInner]**](TopNews200ResponseTopNewsInnerNewsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


