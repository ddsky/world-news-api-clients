# WWW::OpenAPIClient::Object::InlineResponse2002

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse2002;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**news_links** | **ARRAY[string]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


