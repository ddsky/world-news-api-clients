# WWW::OpenAPIClient::Object::TopNews200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::TopNews200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**top_news** | [**ARRAY[TopNews200ResponseTopNewsInner]**](TopNews200ResponseTopNewsInner.md) |  | [optional] 
**language** | **string** |  | [optional] 
**country** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


