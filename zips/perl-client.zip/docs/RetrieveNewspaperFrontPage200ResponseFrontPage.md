# WWW::OpenAPIClient::Object::RetrieveNewspaperFrontPage200ResponseFrontPage

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveNewspaperFrontPage200ResponseFrontPage;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**date** | **string** |  | [optional] 
**country** | **string** |  | [optional] 
**image** | **string** |  | [optional] 
**language** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


