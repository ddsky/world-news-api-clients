(ns world-news-api.specs.search-news-200-response
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [world-news-api.specs.search-news-200-response-news-inner :refer :all]
            )
  (:import (java.io File)))


(def search-news-200-response-data
  {
   (ds/req :offset) int?
   (ds/req :number) int?
   (ds/req :available) int?
   (ds/req :news) (s/coll-of search-news-200-response-news-inner-spec)
   })

(def search-news-200-response-spec
  (ds/spec
    {:name ::search-news-200-response
     :spec search-news-200-response-data}))
