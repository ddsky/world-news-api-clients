(ns world-news-api.specs.geo-coordinates-200-response
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def geo-coordinates-200-response-data
  {
   (ds/req :latitude) float?
   (ds/req :longitude) float?
   (ds/opt :city) string?
   })

(def geo-coordinates-200-response-spec
  (ds/spec
    {:name ::geo-coordinates-200-response
     :spec geo-coordinates-200-response-data}))
