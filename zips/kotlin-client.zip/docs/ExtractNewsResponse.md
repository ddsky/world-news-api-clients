
# ExtractNewsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **kotlin.String** |  |  [optional]
**text** | **kotlin.String** |  |  [optional]
**url** | **kotlin.String** |  |  [optional]
**image** | **kotlin.String** |  |  [optional]
**author** | **kotlin.String** |  |  [optional]
**language** | **kotlin.String** |  |  [optional]
**sourceCountry** | **kotlin.String** |  |  [optional]
**sentiment** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]



