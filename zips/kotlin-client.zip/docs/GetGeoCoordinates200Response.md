
# GetGeoCoordinates200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latitude** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**longitude** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**city** | **kotlin.String** |  |  [optional]



