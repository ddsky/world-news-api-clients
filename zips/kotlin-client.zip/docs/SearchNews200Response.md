
# SearchNews200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **kotlin.Int** |  | 
**number** | **kotlin.Int** |  | 
**available** | **kotlin.Int** |  | 
**news** | [**kotlin.collections.List&lt;SearchNews200ResponseNewsInner&gt;**](SearchNews200ResponseNewsInner.md) |  | 



