
# TopNews200ResponseTopNewsInnerNewsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **summary** | **kotlin.String** |  |  [optional] |
| **image** | **kotlin.String** |  |  [optional] |
| **author** | **kotlin.String** |  |  [optional] |
| **id** | **kotlin.Int** |  |  [optional] |
| **text** | **kotlin.String** |  |  [optional] |
| **title** | **kotlin.String** |  |  [optional] |
| **publishDate** | **kotlin.String** |  |  [optional] |
| **url** | **kotlin.String** |  |  [optional] |
| **authors** | **kotlin.collections.List&lt;kotlin.String?&gt;** |  |  [optional] |



