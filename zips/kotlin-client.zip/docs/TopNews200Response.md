
# TopNews200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **topNews** | [**kotlin.collections.List&lt;TopNews200ResponseTopNewsInner&gt;**](TopNews200ResponseTopNewsInner.md) |  |  [optional] |
| **language** | **kotlin.String** |  |  [optional] |
| **country** | **kotlin.String** |  |  [optional] |



