
# SearchNewsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **kotlin.Int** |  | 
**number** | **kotlin.Int** |  | 
**available** | **kotlin.Int** |  | 
**news** | [**kotlin.collections.List&lt;NewsArticle&gt;**](NewsArticle.md) |  | 



