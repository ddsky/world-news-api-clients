
# GeoCoordinatesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latitude** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**longitude** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**city** | **kotlin.String** |  |  [optional]



