
# RetrieveNewsArticlesByIds200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**news** | [**kotlin.collections.List&lt;RetrieveNewsArticlesByIds200ResponseNewsInner&gt;**](RetrieveNewsArticlesByIds200ResponseNewsInner.md) |  |  [optional]



