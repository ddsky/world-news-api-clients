
# ExtractNews200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **title** | **kotlin.String** |  |  [optional] |
| **text** | **kotlin.String** |  |  [optional] |
| **url** | **kotlin.String** |  |  [optional] |
| **image** | **kotlin.String** |  |  [optional] |
| **images** | [**kotlin.collections.List&lt;ExtractNews200ResponseImagesInner&gt;**](ExtractNews200ResponseImagesInner.md) |  |  [optional] |
| **video** | **kotlin.String** |  |  [optional] |
| **videos** | [**kotlin.collections.List&lt;ExtractNews200ResponseVideosInner&gt;**](ExtractNews200ResponseVideosInner.md) |  |  [optional] |
| **publishDate** | **kotlin.String** |  |  [optional] |
| **author** | **kotlin.String** |  |  [optional] |
| **authors** | **kotlin.collections.List&lt;kotlin.String?&gt;** |  |  [optional] |
| **language** | **kotlin.String** |  |  [optional] |



