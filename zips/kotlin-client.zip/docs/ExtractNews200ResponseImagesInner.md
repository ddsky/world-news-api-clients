
# ExtractNews200ResponseImagesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **kotlin.Int** |  |  [optional]
**title** | **kotlin.String** |  |  [optional]
**url** | **kotlin.String** |  |  [optional]
**height** | **kotlin.Int** |  |  [optional]



