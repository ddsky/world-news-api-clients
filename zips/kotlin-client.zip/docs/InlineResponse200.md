
# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **kotlin.Int** |  | 
**number** | **kotlin.Int** |  | 
**available** | **kotlin.Int** |  | 
**news** | [**kotlin.collections.List&lt;InlineResponse200News&gt;**](InlineResponse200News.md) |  | 



