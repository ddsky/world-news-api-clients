
# SearchNews200ResponseNewsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **kotlin.String** |  |  [optional]
**image** | **kotlin.String** |  |  [optional]
**sentiment** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**sourceCountry** | **kotlin.String** |  |  [optional]
**language** | **kotlin.String** |  |  [optional]
**id** | **kotlin.Int** |  |  [optional]
**text** | **kotlin.String** |  |  [optional]
**title** | **kotlin.String** |  |  [optional]
**publishDate** | **kotlin.String** |  |  [optional]
**url** | **kotlin.String** |  |  [optional]
**authors** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional]



