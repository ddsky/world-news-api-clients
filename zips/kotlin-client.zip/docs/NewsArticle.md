
# NewsArticle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  |  [optional]
**title** | **kotlin.String** |  |  [optional]
**text** | **kotlin.String** |  |  [optional]
**summary** | **kotlin.String** |  |  [optional]
**url** | **kotlin.String** |  |  [optional]
**image** | **kotlin.String** |  |  [optional]
**publishDate** | **kotlin.String** |  |  [optional]
**author** | **kotlin.String** |  |  [optional]
**language** | **kotlin.String** |  |  [optional]
**sourceCountry** | **kotlin.String** |  |  [optional]
**sentiment** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]



