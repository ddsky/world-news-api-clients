# SearchNews200ResponseNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | Option<**String**> |  | [optional]
**image** | Option<**String**> |  | [optional]
**sentiment** | Option<**f64**> |  | [optional]
**author** | Option<**String**> |  | [optional]
**language** | Option<**String**> |  | [optional]
**video** | Option<**String**> |  | [optional]
**title** | Option<**String**> |  | [optional]
**url** | Option<**String**> |  | [optional]
**source_country** | Option<**String**> |  | [optional]
**id** | Option<**i32**> |  | [optional]
**text** | Option<**String**> |  | [optional]
**publish_date** | Option<**String**> |  | [optional]
**authors** | Option<**Vec<String>**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


