# SearchNewsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **i32** |  | 
**number** | **i32** |  | 
**available** | **i32** |  | 
**news** | [**Vec<crate::models::NewsArticle>**](NewsArticle.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


