# InlineResponse200

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **i32** |  | 
**number** | **i32** |  | 
**available** | **i32** |  | 
**news** | [**Vec<crate::models::InlineResponse200News>**](inline_response_200_news.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


