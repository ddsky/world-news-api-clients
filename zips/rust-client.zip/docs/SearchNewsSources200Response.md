# SearchNewsSources200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | Option<**i32**> |  | [optional]
**sources** | Option<[**Vec<models::SearchNewsSources200ResponseSourcesInner>**](searchNewsSources_200_response_sources_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


