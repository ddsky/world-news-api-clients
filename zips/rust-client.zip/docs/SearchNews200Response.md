# SearchNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **i32** |  | 
**number** | **i32** |  | 
**available** | **i32** |  | 
**news** | [**Vec<crate::models::SearchNews200ResponseNewsInner>**](search_news_200_response_news_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


