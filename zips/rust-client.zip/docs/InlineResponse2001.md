# InlineResponse2001

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | Option<**String**> |  | [optional]
**text** | Option<**String**> |  | [optional]
**url** | Option<**String**> |  | [optional]
**image** | Option<**String**> |  | [optional]
**author** | Option<**String**> |  | [optional]
**language** | Option<**String**> |  | [optional]
**source_country** | Option<**String**> |  | [optional]
**sentiment** | Option<**f32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


