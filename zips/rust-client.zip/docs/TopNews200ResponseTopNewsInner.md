# TopNews200ResponseTopNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**news** | Option<[**Vec<models::TopNews200ResponseTopNewsInnerNewsInner>**](topNews_200_response_top_news_inner_news_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


