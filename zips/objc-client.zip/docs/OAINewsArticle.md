# OAINewsArticle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** |  | [optional] 
**title** | **NSString*** |  | [optional] 
**text** | **NSString*** |  | [optional] 
**summary** | **NSString*** |  | [optional] 
**url** | **NSString*** |  | [optional] 
**image** | **NSString*** |  | [optional] 
**publishDate** | **NSString*** |  | [optional] 
**author** | **NSString*** |  | [optional] 
**language** | **NSString*** |  | [optional] 
**sourceCountry** | **NSString*** |  | [optional] 
**sentiment** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


