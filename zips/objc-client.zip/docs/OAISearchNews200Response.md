# OAISearchNews200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **NSNumber*** |  | [optional] 
**number** | **NSNumber*** |  | [optional] 
**available** | **NSNumber*** |  | [optional] 
**varNews** | [**NSArray&lt;OAISearchNews200ResponseNewsInner&gt;***](OAISearchNews200ResponseNewsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


