# OAISearchNews200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **NSNumber*** |  | 
**number** | **NSNumber*** |  | 
**available** | **NSNumber*** |  | 
**varNews** | [**NSArray&lt;OAISearchNews200ResponseNewsInner&gt;***](OAISearchNews200ResponseNewsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


