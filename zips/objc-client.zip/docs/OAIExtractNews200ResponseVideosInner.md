# OAIExtractNews200ResponseVideosInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **NSString*** |  | [optional] 
**duration** | **NSNumber*** |  | [optional] 
**thumbnail** | **NSString*** |  | [optional] 
**title** | **NSString*** |  | [optional] 
**url** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


