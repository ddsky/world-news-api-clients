# OAITopNews200ResponseTopNewsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**varNews** | [**NSArray&lt;OAITopNews200ResponseTopNewsInnerNewsInner&gt;***](OAITopNews200ResponseTopNewsInnerNewsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


