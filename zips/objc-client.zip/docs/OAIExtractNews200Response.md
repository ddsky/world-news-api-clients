# OAIExtractNews200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **NSString*** |  | [optional] 
**text** | **NSString*** |  | [optional] 
**url** | **NSString*** |  | [optional] 
**image** | **NSString*** |  | [optional] 
**images** | [**NSArray&lt;OAIExtractNews200ResponseImagesInner&gt;***](OAIExtractNews200ResponseImagesInner.md) |  | [optional] 
**video** | **NSString*** |  | [optional] 
**videos** | [**NSArray&lt;OAIExtractNews200ResponseVideosInner&gt;***](OAIExtractNews200ResponseVideosInner.md) |  | [optional] 
**publishDate** | **NSString*** |  | [optional] 
**author** | **NSString*** |  | [optional] 
**authors** | **NSArray&lt;NSString*&gt;*** |  | [optional] 
**language** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


