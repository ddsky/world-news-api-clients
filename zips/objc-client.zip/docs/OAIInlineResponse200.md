# OAIInlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **NSNumber*** |  | 
**number** | **NSNumber*** |  | 
**available** | **NSNumber*** |  | 
**varNews** | [**NSArray&lt;OAIInlineResponse200News&gt;***](OAIInlineResponse200News.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


