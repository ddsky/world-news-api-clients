# OAISearchNews200ResponseNewsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **NSString*** |  | [optional] 
**image** | **NSString*** |  | [optional] 
**sentiment** | **NSNumber*** |  | [optional] 
**author** | **NSString*** |  | [optional] 
**language** | **NSString*** |  | [optional] 
**video** | **NSString*** |  | [optional] 
**title** | **NSString*** |  | [optional] 
**url** | **NSString*** |  | [optional] 
**sourceCountry** | **NSString*** |  | [optional] 
**_id** | **NSNumber*** |  | [optional] 
**text** | **NSString*** |  | [optional] 
**publishDate** | **NSString*** |  | [optional] 
**authors** | **NSArray&lt;NSString*&gt;*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


