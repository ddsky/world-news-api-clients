# openapi.model.News

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**title** | **String** |  | [optional] 
**text** | **String** |  | [optional] 
**summary** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**author** | **String** |  | [optional] 
**language** | **String** |  | [optional] 
**sourceCountry** | **String** |  | [optional] 
**sentiment** | **num** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


