# openapi.model.SearchNews200Response

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  | 
**number** | **int** |  | 
**available** | **int** |  | 
**news** | [**List<SearchNews200ResponseNewsInner>**](SearchNews200ResponseNewsInner.md) |  | [default to const []]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


