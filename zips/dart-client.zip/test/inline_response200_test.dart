//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.0

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for InlineResponse200
void main() {
  final instance = InlineResponse200();

  group('test InlineResponse200', () {
    // int offset
    test('to test the property `offset`', () async {
      // TODO
    });

    // int number
    test('to test the property `number`', () async {
      // TODO
    });

    // int available
    test('to test the property `available`', () async {
      // TODO
    });

    // List<InlineResponse200News> news (default value: const [])
    test('to test the property `news`', () async {
      // TODO
    });


  });

}
