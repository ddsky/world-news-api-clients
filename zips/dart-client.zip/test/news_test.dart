//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for News
void main() {
  // final instance = News();

  group('test News', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String title
    test('to test the property `title`', () async {
      // TODO
    });

    // String text
    test('to test the property `text`', () async {
      // TODO
    });

    // String summary
    test('to test the property `summary`', () async {
      // TODO
    });

    // String url
    test('to test the property `url`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // String publishDate
    test('to test the property `publishDate`', () async {
      // TODO
    });

    // String author
    test('to test the property `author`', () async {
      // TODO
    });

    // String language
    test('to test the property `language`', () async {
      // TODO
    });

    // String sourceCountry
    test('to test the property `sourceCountry`', () async {
      // TODO
    });

    // num sentiment
    test('to test the property `sentiment`', () async {
      // TODO
    });


  });

}
