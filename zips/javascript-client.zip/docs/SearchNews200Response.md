# Worldnewsapi.SearchNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Number** |  | [optional] 
**number** | **Number** |  | [optional] 
**available** | **Number** |  | [optional] 
**news** | [**[SearchNews200ResponseNewsInner]**](SearchNews200ResponseNewsInner.md) |  | [optional] 


