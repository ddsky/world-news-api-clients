# WorldNewsApi.SearchNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Number** |  | 
**number** | **Number** |  | 
**available** | **Number** |  | 
**news** | [**[SearchNews200ResponseNewsInner]**](SearchNews200ResponseNewsInner.md) |  | 


