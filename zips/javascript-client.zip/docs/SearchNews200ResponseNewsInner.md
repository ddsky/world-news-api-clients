# Worldnewsapi.SearchNews200ResponseNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**sentiment** | **Number** |  | [optional] 
**language** | **String** |  | [optional] 
**video** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**sourceCountry** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**text** | **String** |  | [optional] 
**category** | **String** |  | [optional] 
**publishDate** | **String** |  | [optional] 
**authors** | **[String]** |  | [optional] 


