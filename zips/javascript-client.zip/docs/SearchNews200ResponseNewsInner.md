# WorldNewsApi.SearchNews200ResponseNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**title** | **String** |  | [optional] 
**text** | **String** |  | [optional] 
**summary** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**publishDate** | **String** |  | [optional] 
**author** | **String** |  | [optional] 
**language** | **String** |  | [optional] 
**sourceCountry** | **String** |  | [optional] 
**sentiment** | **Number** |  | [optional] 


