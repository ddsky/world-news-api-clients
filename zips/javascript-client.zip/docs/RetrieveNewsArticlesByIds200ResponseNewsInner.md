# Worldnewsapi.RetrieveNewsArticlesByIds200ResponseNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**sentiment** | **Number** |  | [optional] 
**catgory** | **String** |  | [optional] 
**language** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**sourceCountry** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**text** | **String** |  | [optional] 
**publishDate** | **String** |  | [optional] 
**authors** | **[String]** |  | [optional] 


