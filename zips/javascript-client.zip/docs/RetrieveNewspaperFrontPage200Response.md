# Worldnewsapi.RetrieveNewspaperFrontPage200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**frontPage** | [**RetrieveNewspaperFrontPage200ResponseFrontPage**](RetrieveNewspaperFrontPage200ResponseFrontPage.md) |  | [optional] 


