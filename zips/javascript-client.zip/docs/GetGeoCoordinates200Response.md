# Worldnewsapi.GetGeoCoordinates200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latitude** | **Number** |  | [optional] 
**longitude** | **Number** |  | [optional] 
**city** | **String** |  | [optional] 


