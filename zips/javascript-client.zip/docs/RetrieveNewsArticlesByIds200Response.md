# Worldnewsapi.RetrieveNewsArticlesByIds200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**news** | [**[RetrieveNewsArticlesByIds200ResponseNewsInner]**](RetrieveNewsArticlesByIds200ResponseNewsInner.md) |  | [optional] 


