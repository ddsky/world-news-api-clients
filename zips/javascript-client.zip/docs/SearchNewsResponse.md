# Worldnewsapi.SearchNewsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Number** |  | 
**number** | **Number** |  | 
**available** | **Number** |  | 
**news** | [**[NewsArticle]**](NewsArticle.md) |  | 


