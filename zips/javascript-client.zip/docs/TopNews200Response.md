# Worldnewsapi.TopNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**topNews** | [**[TopNews200ResponseTopNewsInner]**](TopNews200ResponseTopNewsInner.md) |  | [optional] 
**language** | **String** |  | [optional] 
**country** | **String** |  | [optional] 


