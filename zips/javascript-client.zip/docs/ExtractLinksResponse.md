# WorldNewsApi.ExtractLinksResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**newsLinks** | **[String]** |  | [optional] 


