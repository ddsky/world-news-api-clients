# Worldnewsapi.ExtractNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | [optional] 
**text** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**images** | [**[ExtractNews200ResponseImagesInner]**](ExtractNews200ResponseImagesInner.md) |  | [optional] 
**video** | **String** |  | [optional] 
**videos** | [**[ExtractNews200ResponseVideosInner]**](ExtractNews200ResponseVideosInner.md) |  | [optional] 
**publishDate** | **String** |  | [optional] 
**author** | **String** |  | [optional] 
**authors** | **[String]** |  | [optional] 
**language** | **String** |  | [optional] 


