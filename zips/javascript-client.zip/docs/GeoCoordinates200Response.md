# WorldNewsApi.GeoCoordinates200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latitude** | **Number** |  | 
**longitude** | **Number** |  | 
**city** | **String** |  | [optional] 


