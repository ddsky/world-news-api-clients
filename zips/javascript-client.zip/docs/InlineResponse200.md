# WorldNewsApi.InlineResponse200

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Number** |  | 
**number** | **Number** |  | 
**available** | **Number** |  | 
**news** | [**[InlineResponse200News]**](InlineResponse200News.md) |  | 


