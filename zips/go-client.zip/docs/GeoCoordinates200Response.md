# GeoCoordinates200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Latitude** | **float32** |  | 
**Longitude** | **float32** |  | 
**City** | Pointer to **string** |  | [optional] 

## Methods

### NewGeoCoordinates200Response

`func NewGeoCoordinates200Response(latitude float32, longitude float32, ) *GeoCoordinates200Response`

NewGeoCoordinates200Response instantiates a new GeoCoordinates200Response object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGeoCoordinates200ResponseWithDefaults

`func NewGeoCoordinates200ResponseWithDefaults() *GeoCoordinates200Response`

NewGeoCoordinates200ResponseWithDefaults instantiates a new GeoCoordinates200Response object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLatitude

`func (o *GeoCoordinates200Response) GetLatitude() float32`

GetLatitude returns the Latitude field if non-nil, zero value otherwise.

### GetLatitudeOk

`func (o *GeoCoordinates200Response) GetLatitudeOk() (*float32, bool)`

GetLatitudeOk returns a tuple with the Latitude field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLatitude

`func (o *GeoCoordinates200Response) SetLatitude(v float32)`

SetLatitude sets Latitude field to given value.


### GetLongitude

`func (o *GeoCoordinates200Response) GetLongitude() float32`

GetLongitude returns the Longitude field if non-nil, zero value otherwise.

### GetLongitudeOk

`func (o *GeoCoordinates200Response) GetLongitudeOk() (*float32, bool)`

GetLongitudeOk returns a tuple with the Longitude field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLongitude

`func (o *GeoCoordinates200Response) SetLongitude(v float32)`

SetLongitude sets Longitude field to given value.


### GetCity

`func (o *GeoCoordinates200Response) GetCity() string`

GetCity returns the City field if non-nil, zero value otherwise.

### GetCityOk

`func (o *GeoCoordinates200Response) GetCityOk() (*string, bool)`

GetCityOk returns a tuple with the City field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCity

`func (o *GeoCoordinates200Response) SetCity(v string)`

SetCity sets City field to given value.

### HasCity

`func (o *GeoCoordinates200Response) HasCity() bool`

HasCity returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


