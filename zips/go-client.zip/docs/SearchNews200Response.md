# SearchNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offset** | **int32** |  | 
**Number** | **int32** |  | 
**Available** | **int32** |  | 
**News** | [**[]SearchNews200ResponseNewsInner**](SearchNews200ResponseNewsInner.md) |  | 

## Methods

### NewSearchNews200Response

`func NewSearchNews200Response(offset int32, number int32, available int32, news []SearchNews200ResponseNewsInner, ) *SearchNews200Response`

NewSearchNews200Response instantiates a new SearchNews200Response object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewSearchNews200ResponseWithDefaults

`func NewSearchNews200ResponseWithDefaults() *SearchNews200Response`

NewSearchNews200ResponseWithDefaults instantiates a new SearchNews200Response object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetOffset

`func (o *SearchNews200Response) GetOffset() int32`

GetOffset returns the Offset field if non-nil, zero value otherwise.

### GetOffsetOk

`func (o *SearchNews200Response) GetOffsetOk() (*int32, bool)`

GetOffsetOk returns a tuple with the Offset field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOffset

`func (o *SearchNews200Response) SetOffset(v int32)`

SetOffset sets Offset field to given value.


### GetNumber

`func (o *SearchNews200Response) GetNumber() int32`

GetNumber returns the Number field if non-nil, zero value otherwise.

### GetNumberOk

`func (o *SearchNews200Response) GetNumberOk() (*int32, bool)`

GetNumberOk returns a tuple with the Number field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumber

`func (o *SearchNews200Response) SetNumber(v int32)`

SetNumber sets Number field to given value.


### GetAvailable

`func (o *SearchNews200Response) GetAvailable() int32`

GetAvailable returns the Available field if non-nil, zero value otherwise.

### GetAvailableOk

`func (o *SearchNews200Response) GetAvailableOk() (*int32, bool)`

GetAvailableOk returns a tuple with the Available field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAvailable

`func (o *SearchNews200Response) SetAvailable(v int32)`

SetAvailable sets Available field to given value.


### GetNews

`func (o *SearchNews200Response) GetNews() []SearchNews200ResponseNewsInner`

GetNews returns the News field if non-nil, zero value otherwise.

### GetNewsOk

`func (o *SearchNews200Response) GetNewsOk() (*[]SearchNews200ResponseNewsInner, bool)`

GetNewsOk returns a tuple with the News field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNews

`func (o *SearchNews200Response) SetNews(v []SearchNews200ResponseNewsInner)`

SetNews sets News field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


