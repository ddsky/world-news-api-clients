import { ResponseContext, RequestContext, HttpFile, HttpInfo } from '../http/http';
import { Configuration} from '../configuration'

import { ExtractNews200Response } from '../models/ExtractNews200Response';
import { ExtractNews200ResponseImagesInner } from '../models/ExtractNews200ResponseImagesInner';
import { ExtractNews200ResponseVideosInner } from '../models/ExtractNews200ResponseVideosInner';
import { ExtractNewsLinks200Response } from '../models/ExtractNewsLinks200Response';
import { GetGeoCoordinates200Response } from '../models/GetGeoCoordinates200Response';
import { RetrieveNewsArticlesByIds200Response } from '../models/RetrieveNewsArticlesByIds200Response';
import { RetrieveNewsArticlesByIds200ResponseNewsInner } from '../models/RetrieveNewsArticlesByIds200ResponseNewsInner';
import { SearchNews200Response } from '../models/SearchNews200Response';
import { SearchNews200ResponseNewsInner } from '../models/SearchNews200ResponseNewsInner';
import { TopNews200Response } from '../models/TopNews200Response';
import { TopNews200ResponseTopNewsInner } from '../models/TopNews200ResponseTopNewsInner';
import { TopNews200ResponseTopNewsInnerNewsInner } from '../models/TopNews200ResponseTopNewsInnerNewsInner';

import { ObservableNewsApi } from "./ObservableAPI";
import { NewsApiRequestFactory, NewsApiResponseProcessor} from "../apis/NewsApi";

export interface NewsApiExtractNewsRequest {
    /**
     * The url of the news.
     * @type string
     * @memberof NewsApiextractNews
     */
    url: string
    /**
     * Whether to analyze the news (extract entities etc.)
     * @type boolean
     * @memberof NewsApiextractNews
     */
    analyze: boolean
}

export interface NewsApiExtractNewsLinksRequest {
    /**
     * The url of the news.
     * @type string
     * @memberof NewsApiextractNewsLinks
     */
    url: string
    /**
     * Whether to analyze the news (extract entities etc.)
     * @type boolean
     * @memberof NewsApiextractNewsLinks
     */
    analyze: boolean
}

export interface NewsApiGetGeoCoordinatesRequest {
    /**
     * The address or name of the location.
     * @type string
     * @memberof NewsApigetGeoCoordinates
     */
    location: string
}

export interface NewsApiNewsWebsiteToRSSFeedRequest {
    /**
     * The url of the news.
     * @type string
     * @memberof NewsApinewsWebsiteToRSSFeed
     */
    url: string
    /**
     * Whether to analyze the news (extract entities etc.)
     * @type boolean
     * @memberof NewsApinewsWebsiteToRSSFeed
     */
    analyze: boolean
}

export interface NewsApiRetrieveNewsArticlesByIdsRequest {
    /**
     * A comma separated list of news ids.
     * @type string
     * @memberof NewsApiretrieveNewsArticlesByIds
     */
    ids: string
}

export interface NewsApiSearchNewsRequest {
    /**
     * The text to match in the news content (at least 3 characters, maximum 100 characters). By default all query terms are expected, you can use an uppercase OR to search for any terms, e.g. tesla OR ford
     * @type string
     * @memberof NewsApisearchNews
     */
    text?: string
    /**
     * A comma-separated list of ISO 3166 country codes from which the news should originate.
     * @type string
     * @memberof NewsApisearchNews
     */
    sourceCountries?: string
    /**
     * The ISO 6391 language code of the news.
     * @type string
     * @memberof NewsApisearchNews
     */
    language?: string
    /**
     * The minimal sentiment of the news in range [-1,1].
     * @type number
     * @memberof NewsApisearchNews
     */
    minSentiment?: number
    /**
     * The maximal sentiment of the news in range [-1,1].
     * @type number
     * @memberof NewsApisearchNews
     */
    maxSentiment?: number
    /**
     * The news must have been published after this date.
     * @type string
     * @memberof NewsApisearchNews
     */
    earliestPublishDate?: string
    /**
     * The news must have been published before this date.
     * @type string
     * @memberof NewsApisearchNews
     */
    latestPublishDate?: string
    /**
     * A comma-separated list of news sources from which the news should originate.
     * @type string
     * @memberof NewsApisearchNews
     */
    newsSources?: string
    /**
     * A comma-separated list of author names. Only news from any of the given authors will be returned.
     * @type string
     * @memberof NewsApisearchNews
     */
    authors?: string
    /**
     * Filter news by entities (see semantic types).
     * @type string
     * @memberof NewsApisearchNews
     */
    entities?: string
    /**
     * Filter news by radius around a certain location. Format is \&quot;latitude,longitude,radius in kilometers\&quot;. Radius must be between 1 and 100 kilometers.
     * @type string
     * @memberof NewsApisearchNews
     */
    locationFilter?: string
    /**
     * The sorting criteria (publish-time or sentiment).
     * @type string
     * @memberof NewsApisearchNews
     */
    sort?: string
    /**
     * Whether to sort ascending or descending (ASC or DESC).
     * @type string
     * @memberof NewsApisearchNews
     */
    sortDirection?: string
    /**
     * The number of news to skip in range [0,10000]
     * @type number
     * @memberof NewsApisearchNews
     */
    offset?: number
    /**
     * The number of news to return in range [1,100]
     * @type number
     * @memberof NewsApisearchNews
     */
    number?: number
}

export interface NewsApiTopNewsRequest {
    /**
     * The ISO 3166 country code of the country for which top news should be retrieved.
     * @type string
     * @memberof NewsApitopNews
     */
    sourceCountry: string
    /**
     * The ISO 6391 language code of the top news. The language must be one spoken in the source-country.
     * @type string
     * @memberof NewsApitopNews
     */
    language: string
    /**
     * The date for which the top news should be retrieved. If no date is given, the current day is assumed.
     * @type string
     * @memberof NewsApitopNews
     */
    date?: string
    /**
     * Whether to only return basic information such as id, title, and url of the news.
     * @type boolean
     * @memberof NewsApitopNews
     */
    headlinesOnly?: boolean
}

export class ObjectNewsApi {
    private api: ObservableNewsApi

    public constructor(configuration: Configuration, requestFactory?: NewsApiRequestFactory, responseProcessor?: NewsApiResponseProcessor) {
        this.api = new ObservableNewsApi(configuration, requestFactory, responseProcessor);
    }

    /**
     * Extract a news article from a website to a well structure JSON object. The API will return the title, text, URL, images, videos, publish date, authors, language, source country, and sentiment of the news article.
     * Extract News
     * @param param the request object
     */
    public extractNewsWithHttpInfo(param: NewsApiExtractNewsRequest, options?: Configuration): Promise<HttpInfo<ExtractNews200Response>> {
        return this.api.extractNewsWithHttpInfo(param.url, param.analyze,  options).toPromise();
    }

    /**
     * Extract a news article from a website to a well structure JSON object. The API will return the title, text, URL, images, videos, publish date, authors, language, source country, and sentiment of the news article.
     * Extract News
     * @param param the request object
     */
    public extractNews(param: NewsApiExtractNewsRequest, options?: Configuration): Promise<ExtractNews200Response> {
        return this.api.extractNews(param.url, param.analyze,  options).toPromise();
    }

    /**
     * Extract news links from a news website.
     * Extract News Links
     * @param param the request object
     */
    public extractNewsLinksWithHttpInfo(param: NewsApiExtractNewsLinksRequest, options?: Configuration): Promise<HttpInfo<ExtractNewsLinks200Response>> {
        return this.api.extractNewsLinksWithHttpInfo(param.url, param.analyze,  options).toPromise();
    }

    /**
     * Extract news links from a news website.
     * Extract News Links
     * @param param the request object
     */
    public extractNewsLinks(param: NewsApiExtractNewsLinksRequest, options?: Configuration): Promise<ExtractNewsLinks200Response> {
        return this.api.extractNewsLinks(param.url, param.analyze,  options).toPromise();
    }

    /**
     * Retrieve the latitude and longitude of a location name. Given this information you can fill the location-filter parameter in the news search endpoint.
     * Get Geo Coordinates
     * @param param the request object
     */
    public getGeoCoordinatesWithHttpInfo(param: NewsApiGetGeoCoordinatesRequest, options?: Configuration): Promise<HttpInfo<GetGeoCoordinates200Response>> {
        return this.api.getGeoCoordinatesWithHttpInfo(param.location,  options).toPromise();
    }

    /**
     * Retrieve the latitude and longitude of a location name. Given this information you can fill the location-filter parameter in the news search endpoint.
     * Get Geo Coordinates
     * @param param the request object
     */
    public getGeoCoordinates(param: NewsApiGetGeoCoordinatesRequest, options?: Configuration): Promise<GetGeoCoordinates200Response> {
        return this.api.getGeoCoordinates(param.location,  options).toPromise();
    }

    /**
     * Turn a news website into an RSS feed. Any page of a news website can be turned into an RSS feed. Provide the URL to the page and the API will return an RSS feed with the latest news from that page.
     * News Website to RSS Feed
     * @param param the request object
     */
    public newsWebsiteToRSSFeedWithHttpInfo(param: NewsApiNewsWebsiteToRSSFeedRequest, options?: Configuration): Promise<HttpInfo<any>> {
        return this.api.newsWebsiteToRSSFeedWithHttpInfo(param.url, param.analyze,  options).toPromise();
    }

    /**
     * Turn a news website into an RSS feed. Any page of a news website can be turned into an RSS feed. Provide the URL to the page and the API will return an RSS feed with the latest news from that page.
     * News Website to RSS Feed
     * @param param the request object
     */
    public newsWebsiteToRSSFeed(param: NewsApiNewsWebsiteToRSSFeedRequest, options?: Configuration): Promise<any> {
        return this.api.newsWebsiteToRSSFeed(param.url, param.analyze,  options).toPromise();
    }

    /**
     * Retrieve information about one or more news articles by their ids. The ids can be retrieved from the search news or top news APIs.
     * Retrieve News Articles by Ids
     * @param param the request object
     */
    public retrieveNewsArticlesByIdsWithHttpInfo(param: NewsApiRetrieveNewsArticlesByIdsRequest, options?: Configuration): Promise<HttpInfo<RetrieveNewsArticlesByIds200Response>> {
        return this.api.retrieveNewsArticlesByIdsWithHttpInfo(param.ids,  options).toPromise();
    }

    /**
     * Retrieve information about one or more news articles by their ids. The ids can be retrieved from the search news or top news APIs.
     * Retrieve News Articles by Ids
     * @param param the request object
     */
    public retrieveNewsArticlesByIds(param: NewsApiRetrieveNewsArticlesByIdsRequest, options?: Configuration): Promise<RetrieveNewsArticlesByIds200Response> {
        return this.api.retrieveNewsArticlesByIds(param.ids,  options).toPromise();
    }

    /**
     * Search and filter news by text, date, location, language, and more. The API returns a list of news articles matching the given criteria. You can set as many filtering parameters as you like, but you have to set at least one, e.g. text or language.
     * Search News
     * @param param the request object
     */
    public searchNewsWithHttpInfo(param: NewsApiSearchNewsRequest = {}, options?: Configuration): Promise<HttpInfo<SearchNews200Response>> {
        return this.api.searchNewsWithHttpInfo(param.text, param.sourceCountries, param.language, param.minSentiment, param.maxSentiment, param.earliestPublishDate, param.latestPublishDate, param.newsSources, param.authors, param.entities, param.locationFilter, param.sort, param.sortDirection, param.offset, param.number,  options).toPromise();
    }

    /**
     * Search and filter news by text, date, location, language, and more. The API returns a list of news articles matching the given criteria. You can set as many filtering parameters as you like, but you have to set at least one, e.g. text or language.
     * Search News
     * @param param the request object
     */
    public searchNews(param: NewsApiSearchNewsRequest = {}, options?: Configuration): Promise<SearchNews200Response> {
        return this.api.searchNews(param.text, param.sourceCountries, param.language, param.minSentiment, param.maxSentiment, param.earliestPublishDate, param.latestPublishDate, param.newsSources, param.authors, param.entities, param.locationFilter, param.sort, param.sortDirection, param.offset, param.number,  options).toPromise();
    }

    /**
     * Get the top news from a country in a language for a specific date. The top news are clustered from multiple sources in the given country. The more news in a cluster the higher the cluster is ranked.
     * Top News
     * @param param the request object
     */
    public topNewsWithHttpInfo(param: NewsApiTopNewsRequest, options?: Configuration): Promise<HttpInfo<TopNews200Response>> {
        return this.api.topNewsWithHttpInfo(param.sourceCountry, param.language, param.date, param.headlinesOnly,  options).toPromise();
    }

    /**
     * Get the top news from a country in a language for a specific date. The top news are clustered from multiple sources in the given country. The more news in a cluster the higher the cluster is ranked.
     * Top News
     * @param param the request object
     */
    public topNews(param: NewsApiTopNewsRequest, options?: Configuration): Promise<TopNews200Response> {
        return this.api.topNews(param.sourceCountry, param.language, param.date, param.headlinesOnly,  options).toPromise();
    }

}
