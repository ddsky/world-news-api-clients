# OpenapiClient::SearchNewsSources200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **available** | **Integer** |  | [optional] |
| **sources** | [**Array&lt;SearchNewsSources200ResponseSourcesInner&gt;**](SearchNewsSources200ResponseSourcesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchNewsSources200Response.new(
  available: null,
  sources: null
)
```

