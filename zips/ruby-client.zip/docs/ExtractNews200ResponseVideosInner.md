# OpenapiClient::ExtractNews200ResponseVideosInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **summary** | **String** |  | [optional] |
| **duration** | **Integer** |  | [optional] |
| **thumbnail** | **String** |  | [optional] |
| **title** | **String** |  | [optional] |
| **url** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractNews200ResponseVideosInner.new(
  summary: null,
  duration: null,
  thumbnail: null,
  title: null,
  url: null
)
```

