# OpenapiClient::RetrieveNewspaperFrontPage200ResponseFrontPage

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **date** | **String** |  | [optional] |
| **country** | **String** |  | [optional] |
| **image** | **String** |  | [optional] |
| **language** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RetrieveNewspaperFrontPage200ResponseFrontPage.new(
  name: null,
  date: null,
  country: null,
  image: null,
  language: null
)
```

