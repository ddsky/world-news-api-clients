# OpenapiClient::ExtractNewsLinks200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **news_links** | **Array&lt;String&gt;** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractNewsLinks200Response.new(
  news_links: null
)
```

