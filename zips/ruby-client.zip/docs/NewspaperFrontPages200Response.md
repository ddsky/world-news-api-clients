# OpenapiClient::NewspaperFrontPages200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **front_page** | [**NewspaperFrontPages200ResponseFrontPage**](NewspaperFrontPages200ResponseFrontPage.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::NewspaperFrontPages200Response.new(
  front_page: null
)
```

