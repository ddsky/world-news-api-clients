# OpenapiClient::GeoCoordinates200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **latitude** | **Float** |  |  |
| **longitude** | **Float** |  |  |
| **city** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GeoCoordinates200Response.new(
  latitude: null,
  longitude: null,
  city: null
)
```

