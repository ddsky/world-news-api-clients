# OpenapiClient::TopNews200ResponseTopNewsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **news** | [**Array&lt;TopNews200ResponseTopNewsInnerNewsInner&gt;**](TopNews200ResponseTopNewsInnerNewsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::TopNews200ResponseTopNewsInner.new(
  news: null
)
```

