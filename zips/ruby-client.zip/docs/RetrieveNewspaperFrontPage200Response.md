# OpenapiClient::RetrieveNewspaperFrontPage200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **front_page** | [**RetrieveNewspaperFrontPage200ResponseFrontPage**](RetrieveNewspaperFrontPage200ResponseFrontPage.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RetrieveNewspaperFrontPage200Response.new(
  front_page: null
)
```

