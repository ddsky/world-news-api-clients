# OpenapiClient::InlineResponse2002

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **news_links** | **Array&lt;String&gt;** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse2002.new(
  news_links: null
)
```

