# OpenapiClient::SearchNews200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **offset** | **Integer** |  |  |
| **number** | **Integer** |  |  |
| **available** | **Integer** |  |  |
| **news** | [**Array&lt;SearchNews200ResponseNewsInner&gt;**](SearchNews200ResponseNewsInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchNews200Response.new(
  offset: null,
  number: null,
  available: null,
  news: null
)
```

