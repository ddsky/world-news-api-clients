# OpenapiClient::ExtractNews200ResponseImagesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **width** | **Integer** |  | [optional] |
| **title** | **String** |  | [optional] |
| **url** | **String** |  | [optional] |
| **height** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractNews200ResponseImagesInner.new(
  width: null,
  title: null,
  url: null,
  height: null
)
```

