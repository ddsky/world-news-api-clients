package com.worldnewsapi.client.model;

import groovy.transform.Canonical
import com.worldnewsapi.client.model.SearchNews200ResponseNewsInner;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.Arrays;

@Canonical
class SearchNews200Response {
    
    Integer offset
    
    Integer number
    
    Integer available
    
    List<SearchNews200ResponseNewsInner> news = new ArrayList<>()
}
