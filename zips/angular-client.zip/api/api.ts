export * from './news.service';
import { NewsService } from './news.service';
export const APIS = [NewsService];
