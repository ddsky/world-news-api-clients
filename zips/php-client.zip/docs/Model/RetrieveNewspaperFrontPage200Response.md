# # RetrieveNewspaperFrontPage200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**front_page** | [**\OpenAPI\Client\Model\RetrieveNewspaperFrontPage200ResponseFrontPage**](RetrieveNewspaperFrontPage200ResponseFrontPage.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
