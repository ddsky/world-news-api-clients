# # SearchNews200ResponseNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **string** |  | [optional]
**image** | **string** |  | [optional]
**sentiment** | **float** |  | [optional]
**language** | **string** |  | [optional]
**video** | **string** |  | [optional]
**title** | **string** |  | [optional]
**url** | **string** |  | [optional]
**source_country** | **string** |  | [optional]
**id** | **int** |  | [optional]
**text** | **string** |  | [optional]
**category** | **string** |  | [optional]
**publish_date** | **string** |  | [optional]
**authors** | **string[]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
