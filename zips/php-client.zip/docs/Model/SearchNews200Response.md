# # SearchNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  |
**number** | **int** |  |
**available** | **int** |  |
**news** | [**\com.worldnewsapi.client\com.worldnewsapi.client.model\SearchNews200ResponseNewsInner[]**](SearchNews200ResponseNewsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
