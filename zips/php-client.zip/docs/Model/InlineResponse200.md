# # InlineResponse200

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  |
**number** | **int** |  |
**available** | **int** |  |
**news** | [**\com.worldnewsapi.client\com.worldnewsapi.client.model\InlineResponse200News[]**](InlineResponse200News.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
