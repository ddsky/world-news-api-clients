# # SearchNewsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  |
**number** | **int** |  |
**available** | **int** |  |
**news** | [**\OpenAPI\Client\Model\NewsArticle[]**](NewsArticle.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
