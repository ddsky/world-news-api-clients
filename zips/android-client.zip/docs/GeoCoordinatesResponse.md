

# GeoCoordinatesResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latitude** | [**BigDecimal**](BigDecimal.md) |  | 
**longitude** | [**BigDecimal**](BigDecimal.md) |  | 
**city** | **String** |  |  [optional]




