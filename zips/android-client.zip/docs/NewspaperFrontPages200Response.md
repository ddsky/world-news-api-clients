

# NewspaperFrontPages200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**frontPage** | [**NewspaperFrontPages200ResponseFrontPage**](NewspaperFrontPages200ResponseFrontPage.md) |  |  [optional]




