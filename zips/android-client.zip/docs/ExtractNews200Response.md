

# ExtractNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  |  [optional]
**text** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**image** | **String** |  |  [optional]
**images** | [**List&lt;ExtractNews200ResponseImagesInner&gt;**](ExtractNews200ResponseImagesInner.md) |  |  [optional]
**video** | **String** |  |  [optional]
**videos** | [**List&lt;ExtractNews200ResponseVideosInner&gt;**](ExtractNews200ResponseVideosInner.md) |  |  [optional]
**publishDate** | **String** |  |  [optional]
**author** | **String** |  |  [optional]
**authors** | **List&lt;String&gt;** |  |  [optional]
**language** | **String** |  |  [optional]




