

# RetrieveNewspaperFrontPage200ResponseFrontPage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**date** | **String** |  |  [optional]
**country** | **String** |  |  [optional]
**image** | **String** |  |  [optional]
**language** | **String** |  |  [optional]




