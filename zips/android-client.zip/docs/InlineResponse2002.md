

# InlineResponse2002

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**newsLinks** | **List&lt;String&gt;** |  |  [optional]




