

# GetGeoCoordinates200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latitude** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**longitude** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**city** | **String** |  |  [optional]




