

# SearchNewsSources200ResponseSourcesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**language** | **String** |  |  [optional]




